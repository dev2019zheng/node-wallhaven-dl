# 01 Search Workspace｜搜索与发现

## 参考图
- `search_workspace_high_fidelity.png`
- 画布尺寸：`1440 × 900 logical px`
- 导出尺寸：`2880 × 1800 @2x`
- 目标平台：Tauri Desktop，优先适配 macOS / Windows / Linux 桌面端。

---

## 1. 页面定位

Search Workspace 是 Wallhaven Desktop 的主工作台。它不是一个“输入关键词然后等结果”的旧时代表单页面，而是一个可连续操作的壁纸发现、筛选、收藏、批量下载入口。页面目标是让用户在一个视图里完成：

1. 搜索 Wallhaven 壁纸。
2. 快速筛选分类、纯净度、排序、分辨率、比例。
3. 浏览瀑布/网格结果。
4. 收藏、预览、下载单张壁纸。
5. 多选并批量下载。
6. 将选择结果保存到集合。

---

## 2. 设计语言

### 2.1 视觉基调

采用 `Dark Premium Desktop UI`。整体感受应接近专业媒体管理工具，而不是网页套壳。设计关键词：

- 深色空间感
- 高对比内容卡片
- 蓝色主操作强调
- 轻量玻璃边框
- 卡片式信息密度
- macOS 原生窗口感

背景不是纯黑，而是 `#07111E → #081728` 的暗蓝渐变。这样可以避免纯黑界面的廉价感，人类终于不用把“深色模式”理解成“把屏幕涂成煤矿”。

### 2.2 色彩规范

| 用途 | Token | 色值 |
|---|---:|---|
| 页面背景 | `bg` | `#07111E` |
| 侧边栏 | `sidebar` | `#08131F` |
| 卡片表面 | `surface` | `#101B2A` |
| 输入/内层表面 | `surface-deep` | `#0B1726` |
| 描边 | `border` | `#203246` |
| 主按钮 | `primary` | `#2F8BFF` |
| 成功 | `success` | `#22C55E` |
| 危险 | `danger` | `#EF4444` |
| 主文本 | `text-primary` | `#F4F7FB` |
| 次文本 | `text-secondary` | `#A9B7C9` |
| 弱文本 | `text-muted` | `#6F7F93` |

### 2.3 字体

- 英文：Inter
- 中文回退：Noto Sans CJK SC / PingFang SC / Microsoft YaHei
- 页面标题：28px / 34px / Semibold
- 区块标题：20px / 28px / Semibold
- 正文：13px / 20px / Regular
- 标签：10px / 14px / Semibold / Uppercase

---

## 3. 页面结构

### 3.1 全局框架

逻辑坐标基于 `1440 × 900`。

| 区域 | 坐标 | 尺寸 | 说明 |
|---|---:|---:|---|
| 顶部窗口栏 | `x0 y0` | `1440 × 58` | macOS traffic lights、产品名、全局快捷入口 |
| 左侧导航 | `x16 y70` | `198 × 808` | 主导航、Collections、用户入口 |
| 主内容区 | `x244 y82` | `932 × 802` | 搜索、筛选、结果网格 |
| 右侧 Inspector | `x1202 y132` | `210 × 716` | 批量选择与详情面板 |

页面使用 8pt Grid，但允许 12/14/18px 间距作为视觉微调。所有主要 Panel 圆角为 20px，卡片圆角为 16px。

---

## 4. 组件规范

### 4.1 Sidebar

Sidebar 是全局导航容器，固定宽度 `198px`。当前页面高亮使用：

- 背景：`#123252`
- 描边：`#1E5A91`
- 图标：`primary`
- 文字：`text-primary`

导航项高度 42px，间距 8px。导航顺序固定：

1. Search
2. Downloads
3. Gallery
4. Settings

Collections 分区显示本地分类计数。计数右对齐，避免因为不同数字宽度导致标签抖动，毕竟连数字都会让 UI 抖，人类软件工程真是脆弱。

### 4.2 Search Bar

搜索栏坐标 `x244 y132 w796 h42`。左侧搜索图标，placeholder 为：

`Search for wallpapers  (e.g. mountains, anime, space...)`

交互规则：

- 输入时 300ms debounce。
- 按 Enter 立即搜索。
- `⌘K / Ctrl+K` 聚焦搜索框。
- loading 状态下右侧 Search 按钮变为 spinner。
- 搜索失败时搜索框描边变 `danger`，并在下方显示 12px 错误提示。

### 4.3 Filter Row

筛选器一行 6 个：

1. Category
2. Purity
3. Sorting
4. Resolution
5. Aspect Ratio
6. More Filters

每个筛选器为 132px 宽，More Filters 为 142px。高度 54px。上方 label 9px uppercase，下方值 13px Medium。

More Filters 点击后从按钮下方弹出 Popover，宽 360px。包含：

- Color
- Min resolution
- Ratio
- Seed
- Toplist range
- Exact purity

Popover 动画：向下平移 8px + opacity 0→1，持续 180ms。

### 4.4 Wallpaper Card

卡片尺寸：`260 × 156`。网格 3 列，列间距 18px，行间距 18px。

卡片层级：

1. 壁纸缩略图。
2. 顶部黑色渐变遮罩。
3. 底部黑色渐变遮罩。
4. 左上角 resolution pill。
5. 右上角收藏按钮。
6. 底部作者与统计信息。
7. 选中时蓝色描边与 check badge。

Hover 状态：

- 图片 scale：`1.00 → 1.035`
- 卡片 y：`0 → -2px`
- 边框：`#203246 → #2F8BFF`
- 阴影：`0 12px 32px rgba(0,0,0,.36)`
- 快捷操作从底部浮现：Preview / Download / Favorite

选中状态：

- 卡片描边 3px `primary`
- 右上角显示圆形 check badge
- Inspector 面板同步更新数量和批量操作

### 4.5 Inspector

右侧 Inspector 是 Search 页的重要差异化设计。它把“多选以后要做什么”明确化，避免用户在网格里迷路。

状态：

| 状态 | 内容 |
|---|---|
| 未选择 | 显示快捷说明、最近下载目录、常用筛选 |
| 单选 | 显示大图预览、metadata、单张操作 |
| 多选 | 显示 selected count、批量下载、保存集合、清除选择 |

主按钮 `Start download` 高度 48px，圆角 14px。任何批量行为都必须先进入队列，再跳转/提示 Downloads 页。

---

## 5. 交互状态

### 5.1 Empty

首次进入无搜索历史时：

- 搜索框保持焦点
- 网格位置显示推荐关键词 chip
- 右侧 Inspector 显示“Start with a query”

### 5.2 Loading

搜索中：

- 网格显示 skeleton card，尺寸与真实卡片一致。
- Search 按钮变成 spinner。
- 筛选器可见但 disabled opacity 60%。
- 允许用户取消请求。

### 5.3 Results

返回结果后：

- 顶部显示 `24,183 results · Page 1 of 967`
- 默认 grid view
- pagination 固定在结果区底部

### 5.4 Multi-select

触发方式：

- Cmd/Ctrl + Click
- Shift + Click
- 点击卡片右上 selection hotspot
- 从 Inspector 中 `Select similar`

多选时底部可以出现轻量 Floating Batch Bar，但本设计以右侧 Inspector 为主承载。

### 5.5 Preview Drawer

单击卡片非按钮区域打开 Preview Drawer。Drawer 从右侧滑出，宽 520px，覆盖 Inspector 或替换 Inspector。包含：

- 大图
- 分辨率
- 文件大小
- Tags
- Wallhaven ID
- Source link
- Download
- Save collection

动画：`translateX(24px) + opacity`，280ms。

---

## 6. 动效规范

| 事件 | 动画 |
|---|---|
| 页面切换 | 350ms fade + content slide 12px |
| 卡片 Hover | 120ms scale + border |
| 筛选器打开 | 180ms popover drop |
| 多选 badge | 180ms spring scale |
| Inspector 更新 | 180ms crossfade |
| 下载加入队列 | card mini clone 飞向 Downloads nav，280ms |

所有动画应使用：

`cubic-bezier(0.22, 1, 0.36, 1)`

---

## 7. 键盘操作

| 快捷键 | 行为 |
|---|---|
| `⌘K / Ctrl+K` | 聚焦搜索 |
| `Enter` | 执行搜索 |
| `Esc` | 关闭弹层 / 取消多选 |
| `↑ ↓ ← →` | 网格焦点移动 |
| `Space` | 选择当前卡片 |
| `D` | 下载当前卡片 |
| `F` | 收藏 |
| `⌘A / Ctrl+A` | 选择当前页全部 |

---

## 8. Agent 还原要求

1. 严格使用 `1440 × 900` 逻辑画布做布局基准。
2. 导出图为 `@2x`，但代码中使用逻辑像素。
3. 不要使用浏览器默认 select 样式，必须自定义 Select/Popover。
4. 卡片图片必须 `object-fit: cover`。
5. 网格必须支持虚拟列表，结果数量可能非常大。
6. 所有搜索状态必须可恢复，刷新后保留最后一次 query/filter/page。
7. 多选状态不可丢失，除非用户执行 Clear 或切换新的 query。
8. Preview Drawer 与 Inspector 不要同时抢焦点。
9. Download 行为必须写入统一任务队列，不允许在 Search 页直接下载后失联。
10. 开发时以图片为视觉准绳，以本 MD 为交互准绳。
