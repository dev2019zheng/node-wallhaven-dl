# 04 Settings｜应用设置

## 参考图
- `settings_high_fidelity.png`
- 画布尺寸：`1440 × 900 logical px`
- 导出尺寸：`2880 × 1800 @2x`

---

## 1. 页面定位

Settings 是应用配置中心，负责 API Key、下载路径、代理、缓存、高级选项。目标不是堆一堆表单，而是让用户清楚知道：

1. 当前配置是否有效。
2. 下一次下载会落在哪里。
3. 代理是否启用。
4. 本地图库是否受路径变化影响。
5. 哪些设置会立即生效，哪些只影响未来任务。

设置页最糟糕的设计就是“你改了，但不知道有没有用”。所以本设计把 Effective destination 放在右侧，实时解释配置结果。产品终于开始对用户说人话，令人欣慰。

---

## 2. 设计语言

Settings 采用双栏管理界面：

- 左侧为可编辑配置。
- 右侧为只读摘要与结果解释。
- 危险操作隐藏在高级区。
- API Key 默认遮罩。
- 路径配置强调“未来下载”和“已有图库记录”之间的区别。

整体更克制，不使用大面积图片，避免干扰配置阅读。

---

## 3. 页面结构

| 区域 | 坐标 | 尺寸 | 说明 |
|---|---:|---:|---|
| 左侧导航 | `x16 y70` | `198 × 808` | 全局导航 |
| 标题区 | `x244 y82` | `996 × 48` | 页面标题、同步状态 |
| 设置主面板 | `x244 y150` | `686 × 698` | API、下载目录、代理 |
| 摘要面板 | `x960 y150` | `452 × 698` | 生效路径、模式、兼容性、缓存 |

---

## 4. 组件规范

### 4.1 API Key

API Key 输入框：

- 坐标 `x274 y282 w620 h42`
- 默认 masked
- 输入时仍 masked
- 右侧可添加 eye icon 切换显示
- Save on blur 或点击 Validate key 后保存
- 空值表示清除本地 key

交互：

1. 用户输入 key。
2. 点击 Validate key。
3. 按钮进入 loading。
4. 成功显示绿色 toast：`API key validated`
5. 失败显示错误：`Invalid or expired key`

安全要求：

- 不要把 key 写入日志。
- 不要在 UI 事件流中暴露完整 key。
- 配置文件中建议使用系统安全存储；如果只用 Tauri Store，需明确风险。

### 4.2 Download Directory

输入框显示自定义目录路径。按钮：

- Choose：打开系统目录选择器。
- Use app default directory：清除自定义目录，回到默认路径。

路径规则：

- 必须是绝对路径。
- 不存在时提示创建。
- 无权限时显示错误。
- 切换路径只影响未来下载，不移动历史文件。

### 4.3 Network Proxy

代理配置：

- Protocol select：HTTP / SOCKS5
- Address input：host:port
- 留空表示直连
- 校验失败时错误提示必须在输入框下方显示

建议增加 Test connection 按钮，检测 Wallhaven API 是否可达。

### 4.4 Effective Destination

右侧蓝色高亮卡片说明下一次下载实际路径。这个区域非常重要，不能删。它解决配置表单的可解释性问题。

显示内容：

- Next downloads
- Mode
- Default app directory
- Gallery compatibility
- Cache

当用户编辑左侧路径时，右侧内容实时更新，但在保存前显示 `Unsaved changes` badge。

### 4.5 Toggles

底部 toggles：

- Launch at login
- Ask before deleting local file
- Telemetry

Toggle 规范：

- 宽 40px，高 22px
- on：轨道 `#123252`，圆点 `primary`
- off：轨道 `#223044`，圆点 `text-muted`

---

## 5. 设置状态

### 5.1 Default

无自定义路径时：

- Mode：App default directory
- Next downloads：默认路径
- Custom path 输入框 placeholder

### 5.2 Custom Directory

设置自定义路径后：

- Mode：Custom directory
- Next downloads：自定义路径
- Default app directory 仍显示，用于回退

### 5.3 Invalid Directory

路径无效时：

- 输入框 danger 描边
- 错误文案：`Folder does not exist or is not writable`
- Save disabled
- 右侧摘要卡片显示 warning

### 5.4 Proxy Error

代理不可达时：

- Proxy 输入框 danger 描边
- Test connection 显示 failed
- Search / Downloads 页顶部状态 badge 显示 `Proxy unavailable`

### 5.5 Cache Cleaning

点击清理缓存：

- 显示确认 Dialog
- 清理中显示 progress
- 完成后右侧 Cache 卡片更新
- 不得删除用户下载的原始壁纸

---

## 6. 动效规范

| 事件 | 动画 |
|---|---|
| 输入框 focus | 120ms border color |
| Validate loading | spinner 180ms loop |
| 摘要更新 | 180ms crossfade |
| Toggle | knob 160ms translate |
| 错误出现 | 160ms fade + y 4px |
| 清理缓存完成 | success toast 250ms |

---

## 7. 数据持久化建议

```ts
type SettingsState = {
  wallhavenApiKey?: string;
  downloadDirectory?: string;
  proxy?: {
    protocol: "http" | "socks5";
    address: string;
  };
  launchAtLogin: boolean;
  confirmBeforeDelete: boolean;
  telemetryEnabled: boolean;
  cacheSizeBytes: number;
};
```

后端命令建议：

- `settings_get`
- `settings_set_api_key`
- `settings_validate_api_key`
- `settings_set_download_directory`
- `settings_reset_download_directory`
- `settings_test_proxy`
- `settings_clear_cache`
- `settings_get_effective_destination`

---

## 8. Agent 还原要求

1. Settings 不允许做成一整页裸表单，必须保持左右解释结构。
2. API key 默认必须隐藏。
3. 所有路径必须经过后端验证。
4. 自定义路径只影响未来下载，不能改变历史图库记录。
5. 右侧 Effective Destination 必须根据左侧表单实时变化。
6. 清理缓存不能删除用户壁纸原图。
7. Invalid 状态要阻止保存。
8. 表单错误信息显示在控件附近，不要只用 toast。
9. 设置保存成功后必须有反馈。
10. Settings 的配置结果要被 Search、Downloads、Gallery 三个页面消费。
