# 03 Local Library｜本地图库

## 参考图
- `local_library_high_fidelity.png`
- 画布尺寸：`1440 × 900 logical px`
- 导出尺寸：`2880 × 1800 @2x`

---

## 1. 页面定位

Local Library 是用户的本地壁纸资产管理中心。它负责把下载下来的文件从“散落在文件夹里的图片”升级为可搜索、可筛选、可收藏、可设为桌面的资产库。

核心目标：

1. 浏览本地壁纸。
2. 搜索本地文件名、标签、Wallhaven ID。
3. 按 Favorites / 4K / Nature / Anime 等筛选。
4. 查看壁纸详情。
5. 设置桌面、打开文件、删除、管理标签。
6. 支持时间线回溯。

---

## 2. 设计语言

Gallery 页面比 Search 更强调图片展示。Search 是发现，Gallery 是资产管理。视觉上：

- 图片面积更大。
- 控件密度略低。
- 右侧 Detail Panel 提供选中资产的操作。
- 下方 Timeline 用来传达“归档历史”。

Local Library 不应该看起来像文件管理器换皮。文件管理器已经够多了，再造一个平庸的，宇宙不会感谢我们。

---

## 3. 页面结构

| 区域 | 坐标 | 尺寸 | 说明 |
|---|---:|---:|---|
| 左侧导航 | `x16 y70` | `198 × 808` | 全局导航 |
| 标题区 | `x244 y82` | `980 × 48` | 页面标题、SQLite 状态 |
| 顶部工具栏 | `x244 y132` | `974 × 42` | 搜索、筛选 chip、视图切换 |
| 状态条 | `x244 y196` | `968 × 54` | 当前显示数量、路径 |
| 图片网格 | `x244 y278` | `908 × 282` | 本地缩略图 |
| Timeline | `x244 y596` | `716 × 252` | 归档时间线 |
| Detail Panel | `x984 y278` | `428 × 570` | 选中壁纸详情 |

---

## 4. 组件规范

### 4.1 Top Toolbar

Local Search：

- 宽 356px
- 高 42px
- placeholder：`Search local library`
- 搜索范围：filename、wallhavenId、tags、collection、local path
- 输入 debounce：200ms

Filter Chips：

- All
- Favorites
- 4K
- Nature
- Anime

Chip 选中态使用 Search 页相同的蓝色高亮，保持系统一致。

View Switch：

- Grid
- Timeline
- List

当前设计默认 Grid。List 可作为后续扩展，但组件结构要预留。

### 4.2 Status Banner

状态条用于说明当前图库范围：

`Showing 60 of 1,256 archived wallpapers.`

右侧显示当前图库路径。路径过长时：

- 中间省略
- hover 显示 tooltip
- 点击可复制路径

### 4.3 Wallpaper Grid

卡片尺寸：`220 × 132`。四列布局，列间距 16px，行间距 18px。

与 Search 页复用同一 Wallpaper Card 组件，但 Gallery 模式下：

- 更突出文件名。
- 默认不显示下载按钮。
- 显示本地操作：Set Desktop / Reveal / Tags。
- 选中后右侧 Detail Panel 更新。

Hover 操作：

- Set desktop
- Reveal file
- Favorite
- More

多选操作：

- Add tags
- Move to collection
- Delete local files
- Export list

### 4.4 Detail Panel

Detail Panel 是本页主操作区。单选状态下显示：

1. 大图预览 `374 × 210`
2. 文件名
3. 分辨率、大小、纯净度
4. 标签 chips
5. Set desktop
6. Reveal file
7. Delete

交互规则：

- 点击 Set desktop 后显示 success toast。
- Reveal file 调用系统文件管理器。
- Delete 必须二次确认。
- 标签 chip 支持编辑，Enter 创建新标签。

### 4.5 Timeline

Timeline 用于帮助用户按下载时间查找素材。显示：

- Today
- Yesterday
- Last 7 days
- Month grouping

点击 Open group 后，顶部筛选范围变成该时间段。状态条同步更新。

---

## 5. 数据模型建议

```ts
type LocalWallpaper = {
  id: string;
  wallhavenId: string;
  filename: string;
  localPath: string;
  width: number;
  height: number;
  fileSize: number;
  purity: "sfw" | "sketchy" | "nsfw";
  sourceUrl?: string;
  thumbnailUrl: string;
  tags: string[];
  collections: string[];
  favorite: boolean;
  downloadedAt: string;
  lastOpenedAt?: string;
};
```

SQLite 表建议：

- wallpapers
- tags
- wallpaper_tags
- collections
- wallpaper_collections
- download_tasks

Gallery 页面只读不够，必须支持 metadata 更新。否则这就只是“带缩略图的文件夹”，技术含量约等于给纸箱贴便利贴。

---

## 6. 交互状态

### 6.1 Empty Library

没有本地壁纸时：

- 显示空状态插画
- 主按钮：Go to Search
- 次按钮：Import folder
- 文案强调“下载后自动归档”

### 6.2 Loading Library

加载大量本地壁纸时：

- 显示 skeleton grid
- 每批加载 60 张
- 缩略图懒加载
- 避免一次性读取全部大图

### 6.3 Selected

选中一张壁纸后：

- 卡片显示 primary 描边
- Detail Panel 更新
- 支持键盘左右移动选择下一张

### 6.4 Multi-select

多选后 Detail Panel 改为 Bulk Panel：

- selected count
- Add tags
- Move collection
- Delete
- Clear selection

### 6.5 Missing File

数据库有记录但本地文件不存在时：

- 卡片显示 broken 状态
- Detail Panel 显示 Missing local file
- 操作：Locate file / Remove record

---

## 7. 动效规范

| 事件 | 动画 |
|---|---|
| 筛选切换 | 180ms grid fade |
| 图片 lazy load | 220ms blur-up |
| 选中卡片 | 180ms border + check scale |
| Detail Panel 更新 | 180ms crossfade |
| Timeline group 展开 | 240ms height transition |
| Toast | 250ms slide up + fade |

---

## 8. Agent 还原要求

1. Gallery 必须使用本地数据库数据，不要实时扫描整个目录作为唯一数据源。
2. 图片缩略图必须懒加载，支持大量文件。
3. 右侧 Detail Panel 与选中状态保持强同步。
4. 删除本地文件必须二次确认。
5. Missing file 状态要可见，不能静默失败。
6. 本地路径可能包含中文、空格、特殊字符，所有 path 操作必须可靠。
7. Tags 与 Collections 要作为可扩展模型实现，不要硬编码在 UI。
8. Set desktop 需要按平台分支实现。
9. 所有本地操作都要返回 Toast。
10. Grid 复用 Search 的卡片视觉语言，但操作集合不同。
