# Codex Start Prompt

```text
你是资深 Tauri + Rust + TypeScript 产品工程师。请读取本项目中的 `Wallhaven_Desktop_DesignSystem_Handoff_v3` 交付包，按 4 个页面目录里的高保真 PNG 与 `UX_Handoff.md` 实现 Wallhaven Desktop v3.0。要求：使用 1440×900 逻辑画布、8pt Grid、Dark Premium Desktop UI、可复用组件系统、虚拟化壁纸网格、实时下载事件流、SQLite 本地图库、Tauri Store/安全存储设置管理。优先实现 AppShell、Sidebar、Search、Downloads、Gallery、Settings 的完整交互状态；视觉以 PNG 为准，交互和状态机以 Markdown 为准。不要使用浏览器默认控件样式，所有 hover/focus/loading/error/empty 状态都要实现。
```
