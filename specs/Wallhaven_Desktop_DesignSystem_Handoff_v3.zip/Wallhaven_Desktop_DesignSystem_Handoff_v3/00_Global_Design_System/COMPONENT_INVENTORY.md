# Component Inventory

## Global
- AppShell
- MacWindowChrome
- Sidebar
- NavItem
- StatusBadge
- Toast
- ConfirmDialog
- Tooltip
- ContextMenu

## Search
- SearchInput
- FilterSelect
- MoreFiltersPopover
- WallpaperCard
- WallpaperGrid
- InspectorPanel
- PreviewDrawer
- Pagination
- BatchActionPanel

## Downloads
- QueueStatsCard
- SpeedChart
- TaskTabs
- DownloadTaskRow
- ProgressBar
- LiveEventStream
- ErrorDetailsPopover

## Gallery
- LocalSearchInput
- FilterChip
- GalleryCard
- DetailPanel
- TimelineGroup
- TagEditor
- MissingFileCard

## Settings
- ApiKeyInput
- PathInput
- DirectoryPickerButton
- ProxyConfig
- EffectiveDestinationCard
- SettingToggle
- CacheCard
