# Wallhaven Desktop Design System Handoff Package v3.0

这是面向开发 Agent / Codex / Claude Code / Cursor / Devin 的完整交付包。

## 核心目录

- `01_Search_Workspace`
- `02_Download_Command_Center`
- `03_Local_Library`
- `04_Settings`

每个页面目录均包含：

- 高保真参考图 `.png`
- 对应页面 `UX_Handoff.md`

## 基础设计系统

- 逻辑画布：1440 × 900
- 图片导出：2880 × 1800 @2x
- Grid：8pt
- 风格：Dark Premium Desktop UI
- 技术假设：Tauri + Rust + TypeScript 前端
