# 02 Download Command Center｜下载任务中心

## 参考图
- `download_command_center_high_fidelity.png`
- 画布尺寸：`1440 × 900 logical px`
- 导出尺寸：`2880 × 1800 @2x`

---

## 1. 页面定位

Downloads 是下载任务的控制中心，负责呈现所有 queued、running、paused、completed、failed 状态。它不是“下载列表”，而是一个任务流水线界面。用户需要知道：

1. 当前有哪些任务。
2. 哪些正在下载。
3. 下载速度如何。
4. 哪些失败，为什么失败。
5. 能否暂停、重试、删除、打开文件。
6. 批量下载是否仍在运行。

下载这种东西最怕“它好像在动，但我不知道它死没死”。所以本页必须把状态、速度、事件流、错误原因全部暴露出来，不要让用户和进度条玩猜谜。

---

## 2. 设计语言

页面延续 Search 的 Dark Premium Desktop 风格，但更偏向 operational dashboard：

- 左侧 Command Center 显示总体状态。
- 中间 Tasks 列表承载主要操作。
- 右侧 Live Events 显示底层事件流。
- 成功状态用绿色，失败用红色，运行用蓝色，暂停用灰色。

下载中心的视觉重点不是“漂亮壁纸”，而是“可信状态”。因此任务列表背景更克制，缩略图只作为识别辅助。

---

## 3. 页面结构

| 区域 | 坐标 | 尺寸 | 说明 |
|---|---:|---:|---|
| 左侧导航 | `x16 y70` | `198 × 808` | 全局导航 |
| 标题区 | `x244 y82` | `996 × 48` | 页面标题、实时状态 |
| Command Center | `x244 y150` | `244 × 698` | 队列健康度、速度、打开目录 |
| Tasks | `x512 y150` | `656 × 698` | 下载任务主列表 |
| Live Events | `x1192 y150` | `220 × 698` | 事件流 |

---

## 4. 组件规范

### 4.1 Command Center

该区域提供下载系统总览。

Stats Card：

- 高度 62px
- 圆角 14px
- 背景 `surface-deep`
- Label：9px uppercase
- Value：22px Bold
- 颜色按状态映射

状态颜色：

| 状态 | 色值 |
|---|---|
| Queued | `text-primary` |
| Running | `primary` |
| Completed | `success` |
| Failed | `danger` |

Speed Chart：

- 图表区 `196 × 120`
- 背景 `#0B1726`
- 主线 `primary`
- 曲线不需要精确数据可视化库，使用轻量 SVG / Canvas 即可。
- 每 500ms 刷新一次，刷新时只更新 path，不重绘整个页面。

### 4.2 Tasks Tabs

Tabs：

- All
- Downloading
- Queued
- Completed
- Failed

当前 Tab 背景 `#123252`，描边 `#1E5A91`。切换 Tab 需要保留滚动位置；切回时恢复上一次位置。

### 4.3 Task Row

任务行高度 94px，间距 18px。

结构：

1. 缩略图 `74 × 54`
2. 文件名
3. 大小/错误信息
4. 状态文字
5. 进度条
6. 进度百分比
7. 行操作按钮

不同状态表现：

| 状态 | 视觉 | 操作 |
|---|---|---|
| Queued | 灰色进度条 0% | Remove / Start now |
| Downloading | 蓝色进度条，速度更新 | Pause / Cancel |
| Paused | 灰色进度条，保留进度 | Resume / Remove |
| Completed | 绿色 100%，check icon | Open / Reveal / Delete |
| Failed | 红色状态，无进度 | Retry / Details / Delete |

### 4.4 Live Events

事件流是工程可信感的来源。每条事件包含：

- 时间戳
- 事件短文案
- 类型色点

事件类型：

| 类型 | 色点 |
|---|---|
| info | `primary` |
| ok | `success` |
| warn | `warning` |
| bad | `danger` |

新事件进入时：

- 从上方插入
- 旧事件向下移动
- 300 条以内保留内存
- 超出后分页/折叠到日志文件

---

## 5. 交互状态

### 5.1 加入队列

从 Search 页批量下载后：

1. 任务进入 Queued。
2. Downloads nav 显示小蓝点。
3. 如果当前在 Downloads 页，Tasks 列表顶部插入新任务。
4. 左侧 Running / Queued 计数同步更新。

### 5.2 Running

下载中任务每 300~500ms 更新一次：

- 已下载大小
- 总大小
- 当前速度
- 进度百分比
- ETA

不要让 React/Vue/Svelte 每个字节更新一次。机器很强，但没必要把 UI 当成挖矿工具。

### 5.3 Pause / Resume

Pause：

- 状态变 Paused
- 进度条保持当前位置
- 行操作变 Resume
- 事件流写入 `paused by user`

Resume：

- 状态变 Downloading
- 继续原任务，不重新创建
- 若后端不支持断点续传，则文案必须明确 `Restarting download`

### 5.4 Failed

失败任务必须显示具体原因：

- network timeout
- 403 unauthorized
- invalid API key
- disk permission denied
- file already exists
- insufficient storage

点击 Details 打开错误详情 Popover，包含 request id、URL、重试次数、建议操作。

### 5.5 Completed

Completed 后行内操作：

- Open
- Reveal in folder
- Copy path
- Delete local file

如果用户点击 Delete，必须二次确认。不要因为一个漂亮按钮就轻易删除用户文件，这种设计罪行应该被钉在产品史耻辱柱上。

---

## 6. 动效规范

| 事件 | 动画 |
|---|---|
| 新任务插入 | 280ms height + opacity |
| 进度更新 | 160ms width transition |
| 状态切换 | 180ms text crossfade |
| 失败闪烁 | 1 次轻微 red border pulse |
| 完成反馈 | check icon 180ms scale |
| Tab 切换 | 180ms content fade |

---

## 7. 后端事件映射

建议统一事件模型：

```ts
type DownloadStatus =
  | "queued"
  | "downloading"
  | "paused"
  | "completed"
  | "failed"
  | "cancelled";

type DownloadEvent = {
  id: string;
  wallpaperId: string;
  filename: string;
  status: DownloadStatus;
  bytesDownloaded: number;
  bytesTotal?: number;
  speedBytesPerSecond?: number;
  errorCode?: string;
  errorMessage?: string;
  createdAt: string;
  updatedAt: string;
};
```

UI 不应直接依赖 Rust 命令返回的一次性结果，而应监听统一事件流。

---

## 8. Agent 还原要求

1. 任务列表必须可滚动，但 Command Center 和 Live Events 固定。
2. 进度条宽度变化必须有动画，不能跳帧。
3. Failed 状态必须保留在列表中，不能自动消失。
4. Completed 状态默认保留，用户可手动清理。
5. 事件流必须和任务状态一致，不能出现任务完成但事件仍显示下载中。
6. 支持批量 Pause all / Resume all。
7. 任务行 hover 时显示更多操作。
8. 切换页面后任务继续更新。
9. 应用重启后恢复未完成任务状态。
10. 下载目标路径必须来自 Settings 的有效配置。
